package kf;

public class KfDTO {
	
	
	String userID;
	int bbsID;
	String bbsTitle;
	String bbsContent;
	String bbsContent2;
	String bbsDate;
	int bbsView;
	String bbsFile;
	String bbsRealFile;
	int bbsGroup;
	
	
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public int getBbsID() {
		return bbsID;
	}
	public void setBbsID(int bbsID) {
		this.bbsID = bbsID;
	}
	public String getBbsTitle() {
		return bbsTitle;
	}
	public void setBbsTitle(String bbsTitle) {
		this.bbsTitle = bbsTitle;
	}
	public String getBbsContent() {
		return bbsContent;
	}
	public void setBbsContent(String bbsContent) {
		this.bbsContent = bbsContent;
	}
	public String getBbsContent2() {
		return bbsContent2;
	}
	public void setBbsContent2(String bbsContent2) {
		this.bbsContent2 = bbsContent2;
	}
	public String getBbsDate() {
		return bbsDate;
	}
	public void setBbsDate(String bbsDate) {
		this.bbsDate = bbsDate;
	}
	public int getBbsView() {
		return bbsView;
	}
	public void setBbsView(int bbsView) {
		this.bbsView = bbsView;
	}
	public String getBbsFile() {
		return bbsFile;
	}
	public void setBbsFile(String bbsFile) {
		this.bbsFile = bbsFile;
	}
	public String getBbsRealFile() {
		return bbsRealFile;
	}
	public void setBbsRealFile(String bbsRealFile) {
		this.bbsRealFile = bbsRealFile;
	}
	public int getBbsGroup() {
		return bbsGroup;
	}
	public void setBbsGroup(int bbsGroup) {
		this.bbsGroup = bbsGroup;
	}
	
	
	

}
